<?php
 include('config.php');
//  $id = $_GET['id'];
$conn = mysqli_connect($sname, $unmae, $password, $db_name);
 $sql = "DELETE  FROM info_pelajar ";
 $hasil = mysqli_query($conn, $sql);
 if ($hasil) {

 echo "<script>alert('Berjaya padam rekod')
 window.location='index.php'</script>";
  }else { 

echo "<script>alert('Tidak berjaya padam rekod')
window.location='index.php'</script>";
    }
?>