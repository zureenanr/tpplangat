<?php
include "config.php"; 
if(isset($_POST['id'])) {   
$id = $_POST ['id']; 
$namapelajar = $_POST['nama_pelajar'];
$nondp = $_POST ['no_ndp'];
$nokp = $_POST['no_kp'];
$nohp = $_POST['no_hp'];
$jantina = $_POST['jantina'];
$sql = "INSERT INTO info_pelajar (id, nama_pelajar, no_ndp, no_kp, no_hp, jantina)
    VALUES ('$id', '$namapelajar', '$nondp', '$nokp', '$nohp', '$jantina')";
    $conn = mysqli_connect($sname, $unmae, $password, $db_name);
    $hasil = mysqli_query($conn, $sql); 
     if ($hasil) {
         echo "<script>alert('Berjaya ditambah')</script>";
         echo "<script>window.location='index.php'</script>";
        
    }else {
         echo "<script>alert('Tidak berjaya kemaskini')</script>";
        echo "<script>window.location='index.php'</script>";
    }
 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
<button><h1><a href="tambahpelajar.php">Tambah Pelajar</a></h1></button>
    <center>
        <table border="table 1">
            <tr>
                <th scope="col1">Id</th>
                <th scope="col2">nama_pelajar</th>
                <th scope="col3">no_ndp</th>
                <th scope="col">no_kp</th>
                <th scope="col5">no_hp</th>
                <th scope="col6">jantina</th>
                <th scope="col7">Operation</th>
                
            </tr>

            <?php
            $conn = mysqli_connect($sname, $unmae, $password, $db_name);
            $sql= "SELECT * FROM info_pelajar ORDER BY id";
            $data= mysqli_query($conn, $sql);
            $id= 1;
            while ($info_pelajar = mysqli_fetch_array($data)){
            ?>
            <tr>
               <td><?php echo $info_pelajar['id']; ?></td>
               <td><?php echo $info_pelajar['nama_pelajar']; ?></td>
               <td><?php echo $info_pelajar['no_ndp']; ?></td>
               <td><?php echo $info_pelajar['no_kp']; ?></td>
               <td><?php echo $info_pelajar['no_hp']; ?></td>
               <td><?php echo $info_pelajar['jantina']; ?></td>
              
               <td><button type="button" class="btn btn-success"><h3><a href="padampelajar.php">Delete</a></h3> </button>      
            </td> 
            </tr>
           <?php $id = $id + 1; 
        }  
            ?></td>
        </table>
    </center>
</body>
</html>