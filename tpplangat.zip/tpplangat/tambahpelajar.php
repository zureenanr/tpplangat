<?php
include('config.php'); 
if(isset($_POST['id'])) { 
$id = $_POST ['id']; 
$namapelajar = $_POST['nama_pelajar'];
$nondp = $_POST ['no_ndp'];
$nokp = $_POST['no_kp'];
$nohp = $_POST['no_hp'];
$jantina = $_POST['jantina'];
    $sql = "INSERT INTO info_pelajar (id, nama_pelajar, no_ndp, no_kp, no_hp, jantina)
    VALUES ( '$id', '$namapelajar', '$nondp', '$nokp', '$nohp', '$jantina')";
    $conn = mysqli_connect($sname, $unmae, $password, $db_name);
    $hasil = mysqli_query($conn, $sql); 
    if ($hasil) {
        echo "<script>alert('Berjaya ditambah')</script>";
        echo "<script>window.location='index.php'</script>";
    }else {
        echo "<script>alert('Tidak berjaya kemaskini')</script>";
        echo "<script>window.location='tambahpelajar.php'</script>";
}}
?>

    <title>TambahPelajar</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="tambahpelajar.css">
  
<body>
<form method="POST" >
    <h1>Tambah Pelajar</h1>
<table>
            <tr>
                <td class=warna name="id" id = "id" > Id </td>
                <td> <input  type="text" name="id" id = "id" placeholder=""required> </td>
            </tr>
            <br>
            <tr>
                <td class=warna name="nama_pelajar" id = "nama_pelajar" > Nama Anda </td>
                <td> <input type="text" name="nama_pelajar" id = "nama_pelajar" placeholder="Ali bin Abu"required > </td>
            </tr>
            <br>
            <tr>
                <td class=warna name="no_ndp" id = "no_ndp" > No NDP Pelajar </td>
                <td> <input  type="text" name="no_ndp" id = "no_ndp" placeholder="23221095"required> </td>
            </tr>
            <br>
            <tr>
                <td class=warna name="no_kp"  id = "no_kp"> No Kad Pengenalan </td>
                <td> <input type="text" name="no_kp"  id = "no_kp" placeholder="030512140435"required ></td>
            </tr>
            <br>
            <tr>
                <td class=warna name="no_hp"  id = "no_hp"> No Telefon </td>
                <td> <input type="text" name="no_hp"  id = "no_hp" placeholder="0176238293"required ></td>
            </tr>
            <br>
            <tr>
            <td class=warna  name="jantina" id="jantina" > Jantina</td>
            <td> <input type="text" name="jantina" id="jantina" placeholder="Lelaki/Perempuan"required ></td>
            </tr>
            <br>
        
</table>  
            <div class="col-12">
            <button class="btn btn-primary" type="submit" >Submit</button>
            <button class="btn btn-secondary" type="reset">Reset</button><br>
            *pilih hanya sekali sahaja
            </div>   
</body>
</html>